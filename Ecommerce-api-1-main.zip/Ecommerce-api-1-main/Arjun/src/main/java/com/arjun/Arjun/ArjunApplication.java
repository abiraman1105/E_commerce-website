package com.arjun.Arjun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArjunApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArjunApplication.class, args);
	}

}
